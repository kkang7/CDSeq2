library(Matrix)
args <- commandArgs(TRUE); stopifnot(length(args)==2L)
r <- normalizePath(args[1])
rawdir <- normalizePath(args[2])
b<-readRDS(file.path(r,'inputs/rosmap_heldout_benchmark_minimal.rds'))
v<-readRDS(file.path(r,'inputs/TRANSFER_TO_MAC_FRESH_V1/inputs/new_donor_scaffold.rds'))
s<-readRDS(file.path(r,'inputs/rosmap_reference_sce.rds'));rc<-SummarizedExperiment::assay(s,'counts')
tm<-read.csv(gzfile(file.path(r,'new_cell_selection/training_nuclei.csv.gz')),stringsAsFactors=FALSE)
rmf<-read.csv(gzfile(file.path(r,'new_cell_selection/reference_nuclei.csv.gz')),stringsAsFactors=FALSE)
files<-c(Ast='Astrocytes.rds',Excit_1='Excitatory_neurons_set1.rds',Excit_2='Excitatory_neurons_set2.rds',Excit_3='Excitatory_neurons_set3.rds',OPC='OPCs.rds',Imm='Immune_cells.rds',Oligo='Oligodendrocytes.rds',Inhib='Inhibitory_neurons.rds',Vascular='Vasculature_cells.rds')
ct<-c(Ast='Astro',Excit_1='Excit',Excit_2='Excit',Excit_3='Excit',OPC='OPC',Imm='Immune',Oligo='Oligo',Inhib='Inhib',Vascular='Vascular')
canon<-function(x){x<-toupper(trimws(as.character(x)));z<-sub('^ROSMAP[-_]?','',x);z<-sub('^0+(?=.)','',z,perl=TRUE);paste0('ROSMAP-',z)}
genes<-b$gene_panel;types<-b$major_celltypes;train<-names(b$truth_expression_counts);ev<-as.character(v$metadata$donor)
a<-array(0,c(2000,7,40),list(genes,types,train));e<-v$counts*0
nc<-matrix(0,40,7,dimnames=list(train,types));ne<-v$n_cells*0;refchecks<-list()
for(component in names(files)){
 message(format(Sys.time()),' Reading original source: ',component)
 obj<-readRDS(file.path(rawdir,files[[component]]))
 counts<-methods::slot(methods::slot(obj,'assays')[['RNA']],'counts');md<-methods::slot(obj,'meta.data')
 stopifnot(identical(colnames(counts),rownames(md)),all(genes%in%rownames(counts)))
 donors<-canon(md$subject);k<-ct[[component]];t<-tm[tm$component==component,,drop=FALSE]
 ix<-match(t$barcode,colnames(counts));stopifnot(!anyNA(ix),!anyDuplicated(ix),identical(donors[ix],t$donor))
 for(i in seq_along(train)){
  jj<-ix[t$donor==train[i]];a[,k,i]<-a[,k,i]+as.numeric(Matrix::rowSums(counts[genes,jj,drop=FALSE]));nc[i,k]<-nc[i,k]+length(jj)
  jj<-which(donors==ev[i]);e[,k,i]<-e[,k,i]+as.numeric(Matrix::rowSums(counts[genes,jj,drop=FALSE]));ne[k,i]<-ne[k,i]+length(jj)
 }
 ir<-which(rmf$component==component);jr<-match(rmf$barcode[ir],colnames(counts));stopifnot(!anyNA(jr),identical(donors[jr],rmf$donor[ir]))
 same<-identical(as.numeric(counts[genes,jr,drop=FALSE]),as.numeric(rc[,ir,drop=FALSE]));stopifnot(same)
 refchecks[[component]]<-data.frame(component=component,reference_nuclei=length(ir),exact_counts=same)
 rm(obj,counts,md);gc();message(format(Sys.time()),' Verified reference block: ',component)
}
truth<-a*0;for(i in seq_along(train))truth[,,i]<-as.matrix(b$truth_expression_counts[[train[i]]])
checks<-c(training_counts=identical(as.numeric(a),as.numeric(truth)),training_nuclei=identical(as.numeric(nc),as.numeric(b$truth_cell_counts)),evaluation_counts=identical(as.numeric(e),as.numeric(v$counts)),evaluation_nuclei=identical(as.numeric(ne),as.numeric(v$n_cells)),reference_order=identical(rmf$reference_cell_id,colnames(rc)))
stopifnot(all(checks))
write.csv(data.frame(check=names(checks),pass=unname(checks)),file.path(r,'new_cell_selection/source_reconstruction_checks.csv'),row.names=FALSE)
write.csv(do.call(rbind,refchecks),file.path(r,'new_cell_selection/source_reference_checks.csv'),row.names=FALSE)
writeLines(c('PASS: all reconstructed training and evaluation counts, nucleus counts, and reference count blocks reproduced exactly from the nine downloaded source files using the NEW frozen selections.','No historical clustering checkpoints or newly clustered Seurat objects were read by this verification.','The selected cells define the new benchmark version; this does not retroactively reproduce the historical benchmark.'),file.path(r,'new_cell_selection/SOURCE_RECONSTRUCTION_VERIFIED.txt'))
cat('All NEW benchmark count inputs independently reproduced from source files.\n')
