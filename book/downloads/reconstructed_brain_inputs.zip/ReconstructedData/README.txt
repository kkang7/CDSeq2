Reconstructed ROSMAP benchmark, frozen 18 October 2026

The four supplied inputs are the NEW verified numerical inputs. Their identities
are in NEW_DATASET_INPUTS.csv. No historical fit or clustering caches are supplied.
The selection manifests freeze this version's training and reference nuclei.

To rerun all brain analyses, from the manuscript bundle directory:
  Rscript ReconstructedData/reproduction/brain/00_preflight.R ReconstructedData/config.R
  Rscript ReconstructedData/reproduction/brain/01_prepare.R ReconstructedData/config.R
  Rscript ReconstructedData/reproduction/brain/02_deconvolution_and_gam7.R ReconstructedData/config.R
  Rscript ReconstructedData/reproduction/brain/03_gam6.R ReconstructedData/config.R
  Rscript ReconstructedData/reproduction/brain/04_continuous_phenotype.R ReconstructedData/config.R
  Rscript ReconstructedData/reproduction/brain/05_eqtl.R ReconstructedData/config.R
  Rscript ReconstructedData/reproduction/brain/06_standard_bayesprism.R ReconstructedData/config.R
  Rscript ReconstructedData/reproduction/brain/07_paper_outputs.R ReconstructedData/config.R

Use the exact bundled CDSeq2 source archive and recorded dependencies for a
version-matched replay. The generated output directory must initially be empty.
Workers can be adjusted in config.R; each CDSeq2 fit uses one computation thread.
Scientific inputs/settings/seeds must not be changed while reusing fit caches.

To independently validate the supplied counts against the downloaded source files:
  Rscript ReconstructedData/verify_source_aggregation.R ReconstructedData /path/to/ROSMAP_AD
The directory must contain all nine source RDS files. This reads source objects
one at a time and checks exact training/evaluation/reference aggregation from
new_cell_selection/. It needs substantial RAM and takes much longer than preflight.
No clustering checkpoints are read. The inputs provide the donor/gene axes and
verification targets; no historical prepared inputs are required.

brain/preprocessing retains the historical reconstruction/audit scripts and their
historical identity guard. Those checks intentionally do not certify this new
input version. Use this configuration and the new selection manifests for v15/v16.
