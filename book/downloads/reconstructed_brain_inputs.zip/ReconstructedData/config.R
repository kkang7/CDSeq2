# Paths are resolved relative to this configuration file by brain/bootstrap.R.
here <- dirname(normalizePath(config_file, mustWork=TRUE))
training_file <- file.path(here,"inputs/rosmap_heldout_benchmark_minimal.rds")
reference_file <- file.path(here,"inputs/rosmap_reference_sce.rds")
transfer_dir <- file.path(here,"inputs/TRANSFER_TO_MAC_FRESH_V1")
output_root <- file.path(here,"rerun_results")
workers <- 4L
# For figure rendering, set CDSEQ2_FIGURE_PYTHON to Python with reportlab/pypdfium2.
