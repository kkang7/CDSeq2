#' logpost computes the log posterior.
#' \code{logpost} outputs the value of log posterior.
#' @param estProp estimated cell type proportions.
#' @param estGEP estimated cell-type-specific GEPs.
#' @param mydata input bulk RNA-seq data.
#' @param alpha hyperparameter for cell type proportion estimation.
#' @param beta hyperparameter for cell-type-specific GEP estimation.
#' @return logpost returns log posterior values.

## simplified log posterior function with estProp and estGEP matrices as input
# coder: Kai Kang

logpost <- function(estProp, estGEP, mydata, alpha, beta){
  #if(class(alpha)!="numeric" || length(alpha)>1){stop("CDSeq: in function logpost, alpha is a positive scalar")}
  #if(class(beta)!="numeric" || length(beta)>1){stop("beta is a positive scalar")}
  if(!is.numeric(alpha)){stop("in function logpost, alpha should be a numeric value")}
  #if(class(beta)!="numeric" && sum(!("matrix" %in% class(beta)))){stop("CDSeq: in function logpost, beta should be a numeric value")}
  mu<-1e8
  delta <- 1e-15
  value <- sum(log(mu* (estGEP+delta))*(t(beta) - 1)) + sum(log(estProp + 1e-20)*(alpha - 1)) + sum((log(mu*(estGEP+delta) %*% estProp  )) * mydata)

  # value <- sum(log(mu*estGEP)*(t(beta) - 1)) + sum(log(estProp)*(alpha - 1)) + sum((log(mu*estGEP %*% estProp  )) * mydata)
  # if(is.infinite(value)){
  #   value <- sum(log(mu* (estGEP+delta))*(t(beta) - 1)) + sum(log(estProp)*(alpha - 1)) + sum((log(mu*(estGEP+delta) %*% estProp  )) * mydata)
  # }

  return(value)
}
