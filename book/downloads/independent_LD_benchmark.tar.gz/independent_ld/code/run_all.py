"""Resume a frozen benchmark. Fits are serial by cohort, parallel within each method."""
import csv, os, pathlib, shutil, subprocess, sys, time
root=pathlib.Path(sys.argv[1]).resolve(); cores=sys.argv[2] if len(sys.argv)>2 else '8'
from guard import guard
guard(root)
(root/'logs').mkdir(exist_ok=True)
(root/'cohorts').mkdir(exist_ok=True)
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
rows=list(csv.DictReader((root/'cohorts.csv').open()))
if '--reverse' in sys.argv: rows=rows[::-1]
for i,row in enumerate(rows,1):
    cohort=row['id']; print(f'{time.ctime()} {i}/{len(rows)} {cohort}',flush=True)
    with (root/'logs'/f'{cohort}.log').open('a') as out:
        p=subprocess.run([os.environ.get('RSCRIPT',shutil.which('Rscript') or '/usr/local/bin/Rscript'),'--vanilla',str(root/'code/run_cohort.R'),str(root),cohort,cores],stdout=out,stderr=subprocess.STDOUT,env=env)
    if p.returncode: raise SystemExit(f'{cohort} failed: see its log; verified caches retained')
print('All cohorts completed',flush=True)
