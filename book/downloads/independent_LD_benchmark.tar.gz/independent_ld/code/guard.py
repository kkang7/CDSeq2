"""Verify immutable computational inputs before using or creating fit caches."""
import csv,hashlib,pathlib

def guard(root):
    root=pathlib.Path(root)
    entries=list(csv.DictReader((root/'computational_inputs.csv').open()))
    for row in entries:
        p=root/row['path'];actual=hashlib.sha256(p.read_bytes()).hexdigest()
        if actual!=row['sha256']:raise RuntimeError(f'Changed computational input: {row["path"]}. Use a new benchmark directory for changed settings.')
    identity=hashlib.sha256('\n'.join(r['path']+':'+r['sha256'] for r in entries).encode()).hexdigest()
    f=root/'CACHE_IDENTITY.txt'
    if f.exists() and f.read_text().strip()!=identity:raise RuntimeError('Cache identity differs from the frozen input set.')
    if not f.exists():f.write_text(identity+'\n')
    return identity
