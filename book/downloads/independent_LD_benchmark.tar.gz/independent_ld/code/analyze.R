a<-commandArgs(TRUE);root<-normalizePath(a[1]);source(file.path(root,'code/benchmark.R'));z<-load_assets(root);s<-z$spec;asset<-z$asset;m<-read.csv(file.path(root,'cohorts.csv'),stringsAsFactors=FALSE);out<-file.path(root,'results');dir.create(out,showWarnings=FALSE)
if(length(a)>1){m<-m[m$id%in%strsplit(a[2],',',fixed=TRUE)[[1]],,drop=FALSE];out<-file.path(root,'interim',gsub(',','_',a[2]));dir.create(out,recursive=TRUE,showWarnings=FALSE)}
map<-asset$targetmap;types<-asset$types;grid<-expand.grid(gene=map$gene,cell_type=types,stringsAsFactors=FALSE);grid$gene_index<-rep(seq_len(nrow(map)),length(types));grid$block<-rep(map$block,length(types))
source(file.path(root,'code/statistics.R'))
allmetrics<-allpr<-alltests<-allnull<-allexpr<-allqc<-allcaps<-list()
for(j in seq_len(nrow(m))){row<-m[j,];message(row$id);sim<-rload(file.path(root,'cohorts',row$id,'simulation.rds'));cd<-rload(file.path(root,'cohorts',row$id,'CDSeq2.rds'));bp<-rload(file.path(root,'cohorts',row$id,'BayesPrism.rds'));sel<-selections(cd$scores)
 profiles<-list(BayesPrism=logprofiles(bp$counts),CDSeq2=logprofiles(cd$counts),Observed_components=logprofiles(sim$truth))
 tlist<-lapply(profiles,tests,gt=sim$genotypes)
 for(method in names(tlist)){
  d<-cbind(grid,tlist[[method]]);d$injected<-as.vector(sim$injected);d$score<-if(method=='CDSeq2')sel$score else NA_real_;d$rank<-if(method=='CDSeq2')sel$rank else NA_integer_;d$outside_training_range<-if(method=='CDSeq2')sel$outside else NA;d$id<-row$id;d$setting<-row$setting;d$n<-row$n;d$h2<-row$h2;d$method<-method
  if(row$h2>0)alltests[[length(alltests)+1]]<-d
  retentions<-if(method=='CDSeq2')c(1,.4,.2,.6,.8)else 1
  for(ret in retentions){keep<-if(ret==1)rep(TRUE,nrow(d))else is.finite(sel$rank)&sel$rank<=floor(ret*nrow(map));workflow<-if(method=='CDSeq2')if(ret==1)'CDSeq2_without'else if(ret==.4)'CDSeq2_with'else paste0('CDSeq2_ret',ret)else method
   for(ct in c('all',types))for(alpha in s$alphas){m1<-measure(d,keep,alpha,ct);allmetrics[[length(allmetrics)+1]]<-cbind(id=row$id,setting=row$setting,n=row$n,h2=row$h2,replicate=row$replicate,workflow=workflow,retention=ret,m1)}
   if(row$h2>0 && ret%in%c(1,.4))for(ct in c('all','Excit','Inhib','Oligo')){cr<-curve(d,keep,ct);if(!is.null(cr)){cr<-cbind(id=row$id,setting=row$setting,replicate=row$replicate,workflow=workflow,cr);allpr[[length(allpr)+1]]<-cr
    for(cap in c(.05,.1,.2)){ok<-which(cr$FDP<=cap);q<-if(length(ok))cr[ok[which.max(cr$TP[ok])],]else cr[1,];if(!length(ok)){q$calls<-q$TP<-q$FP<-q$recall<-q$FDP<-q$F1<-0;q$threshold<-NA_real_;q$precision<-NA_real_};q$cap<-cap;q$threshold_policy<-'retrospective test-truth oracle diagnostic';allcaps[[length(allcaps)+1]]<-q}
   }}
  }
 }
 # Full-panel expression recovery, with target-only frozen retention for the eQTL universe.
 truthlog<-logprofiles(sim$truth);truthlinear<-linearprofiles(sim$truth)
 for(method in c('BayesPrism','CDSeq2')){x<-profiles[[method]];linear<-linearprofiles(if(method=='BayesPrism')bp$counts else cd$counts);rcpm<-vapply(seq_len(nrow(grid)),function(i)if(all(is.finite(c(linear[i,],truthlinear[i,])))&&sd(linear[i,])>0&&sd(truthlinear[i,])>0)cor(linear[i,],truthlinear[i,])else NA_real_,0);r<-vapply(seq_len(nrow(grid)),function(i)if(all(is.finite(c(x[i,],truthlog[i,])))&&sd(x[i,])>0&&sd(truthlog[i,])>0)cor(x[i,],truthlog[i,])else NA_real_,0);allexpr[[length(allexpr)+1]]<-cbind(id=row$id,setting=row$setting,method=method,grid[c('gene','cell_type')],r_logCPM=r,r_CPM=rcpm,selected=if(method=='CDSeq2')sel$retained else NA,score=if(method=='CDSeq2')sel$score else NA_real_,outside_training_range=if(method=='CDSeq2')sel$outside else NA)}
 qc<-bp$preprocessing;qc$id<-row$id;qc$setting<-row$setting;allqc[[length(allqc)+1]]<-qc
 if(row$h2==0){
  nullfile<-file.path(root,'cohorts',row$id,'null_repeats.rds')
  if(file.exists(nullfile)){nu<-rload(nullfile)}else{
   nu<-list();set.seed(as.integer((row$seed+500000)%%2147483646))
   for(r in seq_len(s$null_genotype_repeats)){gt<-generate_genotypes(z$LD,row$n);for(method in names(profiles)){d<-cbind(grid,tests(profiles[[method]],gt));d$injected<-FALSE
    rets<-if(method=='CDSeq2')c(1,.4)else 1;for(ret in rets){keep<-if(ret==1)rep(TRUE,nrow(d))else sel$retained;workflow<-if(method=='CDSeq2')if(ret==1)'CDSeq2_without'else'CDSeq2_with'else method;for(ct in c('all','Excit'))for(alpha in s$alphas)nu[[length(nu)+1]]<-cbind(id=row$id,null_repeat=r,workflow=workflow,measure(d,keep,alpha,ct))}
   }};nu<-do.call(rbind,nu);rsave(nu,nullfile)
  };allnull[[length(allnull)+1]]<-nu
 }
}
source(file.path(root,'code/write_csv_exact.R'))
write<-function(l,name){d<-do.call(rbind,l);write_csv_exact(d,file.path(out,paste0(name,'.csv')));invisible(d)}
metrics<-write(allmetrics,'replicate_metrics');pr<-write(allpr,'precision_recall');write(alltests,'test_results');write(allnull,'global_null_repeats');write(allexpr,'expression_recovery');write(allqc,'BayesPrism_preprocessing');write(allcaps,'retrospective_matched_FDP')
# FDR is the mean replicate FDP including zero-call replicates, never pooled FDP.
keys<-c('setting','n','h2','workflow','retention','scope','alpha');groups<-split(seq_len(nrow(metrics)),interaction(metrics[keys],drop=TRUE));summary<-do.call(rbind,lapply(groups,function(ii){x<-metrics[ii,];d<-x[1,keys,drop=FALSE];d$replicates<-nrow(x);for(nm in c('FDP','full_recall','F1','calls','TP','FP','selected_fraction')){v<-x[[nm]];d[[paste0('mean_',nm)]]<-if(all(is.na(v)))NA_real_ else mean(v,na.rm=TRUE);d[[paste0('se_',nm)]]<-if(sum(is.finite(v))>1)sd(v,na.rm=TRUE)/sqrt(sum(is.finite(v)))else NA_real_};d$pooled_precision<-if(sum(x$calls))sum(x$TP)/sum(x$calls)else NA_real_;d$pooled_recall<-if(sum(x$true_targets))sum(x$TP)/sum(x$true_targets)else NA_real_;d$pooled_F1<-if(sum(x$true_targets))2*sum(x$TP)/(sum(x$calls)+sum(x$true_targets))else NA_real_;d}))
write_csv_exact(summary,file.path(out,'summary_metrics.csv'))
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'));cat('ANALYSIS COMPLETE\n')
