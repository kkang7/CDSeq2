a<-commandArgs(TRUE);root<-if(length(a))a[1]else'CDSeq2_independent_LD_benchmark_v1';dir.create(file.path(root,'inputs'),recursive=TRUE,showWarnings=FALSE)
u<-'https://ftp.1000genomes.ebi.ac.uk/vol1/ftp/release/20130502/ALL.chr22.phase3_shapeit2_mvncall_integrated_v5b.20130502.genotypes.vcf.gz'
t<-Rsamtools::TabixFile(u,index=file.path(root,'inputs/chr22.vcf.gz.tbi'))
h<-Rsamtools::headerTabix(t);samples<-strsplit(tail(h$header,1),'\t',fixed=TRUE)[[1]][-(1:9)]
panel<-read.delim(file.path(root,'inputs/phase3.panel.tsv'),stringsAsFactors=FALSE)
eur<-panel$sample[panel$super_pop=='EUR'];idx<-match(eur,samples)+9L;stopifnot(length(eur)==503,!anyNA(idx))
blocks<-list();qc<-list()
for(b in 1:80){
 start<-20000000L+(b-1L)*50000L;end<-start+24999L;fp<-file.path(root,'inputs',sprintf('LD_block_%02d.rds',b))
 if(file.exists(fp)){z<-readRDS(fp)}else{
 raw<-Rsamtools::scanTabix(t,param=GenomicRanges::GRanges('22',IRanges::IRanges(start,end)))[[1]]
 v<-strsplit(raw,'\t',fixed=TRUE);v<-v[vapply(v,function(x)nchar(x[4])==1&&nchar(x[5])==1&&x[7]=='PASS',TRUE)]
 vv<-lapply(v,function(x){s<-x[idx];if(any(!s%in%c('0|0','0|1','1|0','1|1')))return(NULL);hap<-as.integer(unlist(strsplit(s,'|',fixed=TRUE)));f<-mean(hap);if(f<.05||f>.95)return(NULL);list(hap=hap,variant=paste(x[1],x[2],x[4],x[5],sep=':'),position=as.integer(x[2]),af=f)})
 vv<-Filter(Negate(is.null),vv);if(length(vv)<5){cat("skip sparse window",b,"\n");next}
 z<-list(block=b,chr=22,start=start,end=end,haplotypes=do.call(rbind,lapply(vv,`[[`,'hap')),variants=vapply(vv,`[[`,'','variant'),positions=vapply(vv,`[[`,1L,'position'),af=vapply(vv,`[[`,0,'af'),source_samples=eur,url=u)
 saveRDS(z,fp)
 }
 H<-z$haplotypes;R<-cor(t(H));r2<-R[upper.tri(R)]^2
 qc[[length(qc)+1L]]<-data.frame(block=b,chr=22,start=z$start,end=z$end,variants=nrow(H),haplotypes=ncol(H),median_maf=median(pmin(z$af,1-z$af)),median_pair_r2=median(r2),fraction_pair_r2_gt_08=mean(r2>.8))
 blocks[[length(blocks)+1L]]<-z;cat('block',b,'SNPs',nrow(H),'\n');flush.console();if(length(blocks)==40L)break
}
saveRDS(blocks,file.path(root,'inputs/haplotypes.rds'));write.csv(do.call(rbind,qc),file.path(root,'inputs/LD_reference_QC.csv'),row.names=FALSE)
writeLines(c(u,'European superpopulation (503 individuals, 1006 phased haplotypes).','First 40 windows with at least 5 eligible SNPs among 80 prespecified 25-kb windows spaced every 50 kb from chr22:20000000 (GRCh37).','PASS biallelic SNPs; European reference MAF >= 0.05; all retained SNPs tested, subject to test-cohort MAF >= 0.05.'),file.path(root,'inputs/HAPLOTYPE_SOURCE.txt'))
