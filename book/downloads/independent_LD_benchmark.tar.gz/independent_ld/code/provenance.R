a<-commandArgs(TRUE);root<-normalizePath(a[1]);pkgs<-c('CDSeq2','BayesPrism','mgcv','Rsamtools','Matrix');out<-list()
for(p in pkgs){home<-find.package(p);fs<-sort(unique(c(file.path(home,'DESCRIPTION'),list.files(file.path(home,'R'),full.names=TRUE,recursive=TRUE),list.files(file.path(home,'libs'),full.names=TRUE,recursive=TRUE))));fs<-fs[file.exists(fs)&!dir.exists(fs)];out[[p]]<-data.frame(package=p,version=as.character(packageVersion(p)),relative_path=substring(fs,nchar(home)+2L),md5=unname(tools::md5sum(fs)))}
write.csv(do.call(rbind,out),file.path(root,'installed_package_checksums.csv'),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(root,'fitting_sessionInfo.txt'))
