a<-commandArgs(TRUE);root<-normalizePath(a[1]);id<-a[2];cores<-if(length(a)>2)as.integer(a[3])else 8L
source(file.path(root,'code/benchmark.R'));m<-read.csv(file.path(root,'cohorts.csv'),stringsAsFactors=FALSE);row<-m[m$id==id,,drop=FALSE];stopifnot(nrow(row)==1)
lock<-file.path(root,'cohorts',id,'FIT_LOCK');dir.create(dirname(lock),recursive=TRUE,showWarnings=FALSE);if(file.exists(file.path(dirname(lock),'COMPLETE')))quit(save='no');if(!dir.create(lock,showWarnings=FALSE)){repeat{if(file.exists(file.path(dirname(lock),'COMPLETE')))quit(save='no');Sys.sleep(5)}}
s<-readRDS(file.path(root,'FROZEN_SPEC.rds'));for(p in names(s$packages))stopifnot(as.character(packageVersion(p))==s$packages[[p]])
cat(format(Sys.time()),id,'simulate\n');sim<-simulate_cohort(root,row)
cat(format(Sys.time()),id,'CDSeq2\n');fit_cd(root,row,cores)
cat(format(Sys.time()),id,'BayesPrism\n');fit_bp(root,row,cores)
cat(format(Sys.time()),id,'COMPLETE\n');writeLines('Both native deconvolution fits completed.',file.path(root,'cohorts',id,'COMPLETE'))
unlink(lock,recursive=TRUE)
