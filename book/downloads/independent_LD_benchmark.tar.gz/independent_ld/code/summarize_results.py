"""Describe complete exported outcomes without choosing new thresholds."""
import csv,math,pathlib,statistics,sys,collections
root=pathlib.Path(sys.argv[1]);p=root/'results'
def read(name):return list(csv.DictReader((p/name).open()))
metrics=read('summary_metrics.csv');expr=read('expression_recovery.csv');qc=read('BayesPrism_preprocessing.csv');null=read('global_null_summary.csv')
workflows=['BayesPrism','CDSeq2_without','CDSeq2_with']
settings=['N60_H10','N60_H30','N120_H10','N120_H30','N120_H30_lowExcit','N120_H30_highHeterogeneity']
lines=['Completed independent synthetic-cohort benchmark: descriptive outcome report','Primary q <= 0.05; CDSeq2 selection fixed at top 40%.','FDP refers to direct-target attribution in signal cohorts; no-call FDP = 0.','Precision with no calls is undefined. No new threshold is chosen here.','']
for st in settings:
 lines.append(st)
 for wf in workflows:
  r=next(x for x in metrics if x['setting']==st and x['workflow']==wf and x['scope']=='Excit' and float(x['alpha'])==0.05)
  num=lambda k: float(r[k]) if r[k] else float('nan')
  lines.append(f"  {wf}: mean FDP {num('mean_FDP'):.6f} (MCSE {num('se_FDP'):.6f}), full recall {num('mean_full_recall'):.6f}, mean F1 {num('mean_F1'):.6f}; pooled TP {num('mean_TP')*5:.0f}, FP {num('mean_FP')*5:.0f}, precision {num('pooled_precision'):.6f}.")
  method='CDSeq2' if wf.startswith('CDSeq2') else wf
  z=[x for x in expr if x['setting']==st and x['method']==method and x['cell_type']=='Excit' and (wf!='CDSeq2_with' or x['selected']=='TRUE')]
  vals=[float(x['r_CPM']) for x in z if x['r_CPM']];flags=sum(x['outside_training_range']=='TRUE' for x in z)
  lines.append(f"    Target-expression median CPM r {statistics.median(vals):.6f}, defined {len(vals)}/{len(z)}, out-of-range {flags}/{len(z)}" if method=='CDSeq2' else f"    Target-expression median CPM r {statistics.median(vals):.6f}, defined {len(vals)}/{len(z)}")
 lines.append('')
lines.append('GLOBAL NULL: nominal q <= 0.05; ten expression cohorts x 100 genotype realizations')
for r in null:
 if float(r['alpha'])==0.05:lines.append('  '+str(r))
by=collections.defaultdict(list)
for r in qc:by[r['id']].append(r)
a=[sum(x['retained']=='TRUE' for x in rs)for rs in by.values()];b=[sum(x['retained']=='TRUE' and x['target']=='TRUE' for x in rs)for rs in by.values()]
lines.extend(['',f'BayesPrism retained modeled genes: {min(a)}-{max(a)} of 2000; retained targets: {min(b)}-{max(b)} of 200.'])
text='\n'.join(lines)+'\n';(p/'RESULTS_REPORT.txt').write_text(text);print(text)
