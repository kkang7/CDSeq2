import os,pathlib,subprocess,time,sys
root=pathlib.Path(sys.argv[1]).resolve()
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
pending={f'C07_R{i:02d}' for i in range(1,11)}
while pending:
    for cid in sorted(pending,reverse=True):
        d=root/'cohorts'/cid
        if (d/'null_repeats.rds').exists(): pending.remove(cid); continue
        if not (d/'COMPLETE').exists(): continue
        print(time.ctime(),cid,'null assessment',flush=True)
        with (root/'logs'/f'{cid}_null.log').open('a') as log:
            q=subprocess.run(['/usr/local/bin/Rscript','--vanilla',str(root/'code/analyze.R'),str(root),cid],stdout=log,stderr=subprocess.STDOUT,env=env)
        if not (d/'null_repeats.rds').exists(): raise SystemExit(f'{cid} null assessment failed, exit {q.returncode}')
        pending.remove(cid)
    if pending:time.sleep(30)
print('All null genotype assessments complete',flush=True)
