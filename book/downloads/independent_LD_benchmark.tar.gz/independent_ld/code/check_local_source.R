a<-commandArgs(TRUE);root<-normalizePath(a[1]);src<-normalizePath(a[2]);ns<-asNamespace('CDSeq2');rows<-list()
for(f in list.files(file.path(src,'R'),full.names=TRUE,pattern='[.]R$'))for(e in parse(f)){
 if(is.call(e)&&as.character(e[[1]])%in%c('<-','=')&&is.symbol(e[[2]])&&is.call(e[[3]])&&identical(e[[3]][[1]],as.name('function'))){name<-as.character(e[[2]]);fun<-eval(e[[3]],envir=ns);installed<-get0(name,envir=ns,inherits=FALSE);same<-is.function(installed)&&identical(formals(fun),formals(installed))&&identical(deparse(body(fun)),deparse(body(installed)));rows[[length(rows)+1]]<-data.frame(file=basename(f),function_name=name,matches_installed=same)}
}
d<-do.call(rbind,rows);write.csv(d,file.path(root,'local_source_function_comparison.csv'),row.names=FALSE);print(table(d$matches_installed));if(any(!d$matches_installed))print(d[!d$matches_installed,]);cat('This comparison checks R function bodies and formals only, not equivalence of compiled shared libraries.\n')
