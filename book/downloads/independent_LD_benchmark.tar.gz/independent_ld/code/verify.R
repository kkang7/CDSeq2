a<-commandArgs(TRUE);root<-normalizePath(a[1]);source(file.path(root,'code/benchmark.R'));z<-load_assets(root);s<-z$spec;asset<-z$asset;m<-read.csv(file.path(root,'cohorts.csv'),stringsAsFactors=FALSE);map<-asset$targetmap;types<-asset$types;grid<-expand.grid(gene=map$gene,cell_type=types,stringsAsFactors=FALSE);grid$gene_index<-rep(seq_len(nrow(map)),length(types));grid$block<-rep(map$block,length(types));source(file.path(root,'code/statistics.R'))
checks<-character();ok<-function(x,msg){stopifnot(isTRUE(x));checks<<-c(checks,msg);cat('PASS:',msg,'\n')}
ok(unname(tools::md5sum(file.path(root,'code/benchmark.R')))==unname(s$code_md5[grepl('/benchmark.R$',names(s$code_md5))]),'Generator and inference code unchanged since pre-outcome freeze')
ok(unname(tools::md5sum(file.path(root,'inputs/haplotypes.rds')))==s$LD_md5,'Frozen haplotype reference checksum matches')
ok(nrow(m)==40 && sum(m$n)==3600 && !anyDuplicated(m$seed),'Forty uniquely seeded cohorts and 3600 synthetic individuals')
for(b in z$LD)ok(all(b$haplotypes%in%0:1)&&ncol(b$haplotypes)==1006&&max(abs(rowMeans(b$haplotypes)-b$af))<1e-12,paste('Phased reference integrity block',b$block))
# Hand-coded regression validation on generated toy data, independent of simulation truth.
set.seed(8181);gt<-generate_genotypes(z$LD,60);x<-matrix(rnorm(nrow(grid)*60),nrow(grid),60);x[4,]<-NA_real_;x[9,]<-1
t<-tests(x,gt)
for(i in c(1,2,7,17,201,399,701,1400)){g<-gt[[grid$block[i]]]$g;manual<-vapply(seq_len(nrow(g)),function(v)coef(summary(lm(x[i,]~g[v,])))[2,4],0);expected<-min(1,min(manual)*length(manual));ok(abs(t$p[i]-expected)<1e-10,paste('Independent lm replay gene/type index',i))}
ok(all(t$p[c(4,9)]==1)&!any(t$available[c(4,9)])&&max(abs(t$q-p.adjust(t$p,'BH')))<1e-14,'Unavailable tests and full-family BH preserved')
sc<-expand.grid(gene=map$gene,cell_type=types,stringsAsFactors=FALSE);sc$score<-1;sc$outside_training_range<-FALSE;sel<-selections(sc);ok(all(tapply(sel$retained,grid$cell_type,sum)==80),'Fixed top-40-percent count, including deterministic tie handling')
# Verify one completed native fit numerically; extend through every completed cohort.
completed<-m[vapply(m$id,function(id)file.exists(file.path(root,'cohorts',id,'COMPLETE')),TRUE),]
for(j in seq_len(nrow(completed))){row<-completed[j,];sim<-rload(file.path(root,'cohorts',row$id,'simulation.rds'));cd<-rload(file.path(root,'cohorts',row$id,'CDSeq2.rds'));bp<-rload(file.path(root,'cohorts',row$id,'BayesPrism.rds'));ok(all(colSums(sim$bulk)==200000)&all(grepl('_SYN',colnames(sim$bulk))),paste(row$id,'synthetic count conservation and donor identity'))
 ok(max(abs(apply(cd$counts,c(1,3),sum)-sim$bulk))<1e-6,paste(row$id,'CDSeq2 allocation conservation'))
 ok(max(abs(apply(bp$counts,c(1,3),sum)-sim$bulk[dimnames(bp$counts)[[1]],,drop=FALSE]))<1e-6,paste(row$id,'BayesPrism allocation conservation'))
 ok(if(row$h2>0)identical(as.integer(colSums(sim$injected)[s$causal_types]),rep(40L,3))else !any(sim$injected),paste(row$id,'injection counts and null labels'))
 ok(all(tapply(selections(cd$scores)$retained,grid$cell_type,sum)==80),paste(row$id,'80 selected profiles per type'))
 for(b in sim$genotypes)stopifnot(all(b$g%in%0:2),all(pmin(rowMeans(b$g)/2,1-rowMeans(b$g)/2)>=.05))
 if(j==1){
  # Independent scorer replay using the bundled archived definition or a supplied original workflow.
  scoring_reference<-if(length(a)>1)file.path(a[2],'workflow.R')else file.path(root,'source_snapshot/archived_scoring_workflow.R');if(file.exists(scoring_reference)){e<-new.env();sys.source(scoring_reference,e);e$.da_features<-setdiff(e$.da_features,'composition_loo_r2');f<-e$.da_observables(sim$bulk,asset$mu,cd$proportions);p<-e$predict_direct_variation(f,asset$scorer);ok(max(abs(p$variation_score-cd$scores$score),na.rm=TRUE)<1e-10,'New-cohort GAM6 scores reproduce the archived feature and prediction implementation')}
  tt<-tests(logprofiles(cd$counts),sim$genotypes)
  for(i in c(2,205,603,1301)){xx<-logprofiles(cd$counts)[i,];gg<-sim$genotypes[[grid$block[i]]]$g;if(all(is.finite(xx))&&sd(xx)>0){pp<-vapply(seq_len(nrow(gg)),function(v)coef(summary(lm(xx~gg[v,])))[2,4],0);ok(abs(tt$p[i]-min(1,min(pp)*length(pp)))<1e-10,paste('Native-fit association independent replay',i))}}
 }
}
# When final tables exist, validate every stored q value and every workflow denominator.
f<-file.path(root,'results/test_results.csv')
if(file.exists(f)){
 d<-read.csv(f,stringsAsFactors=FALSE);for(ii in split(seq_len(nrow(d)),paste(d$id,d$method))){v<-d[ii,];stopifnot(nrow(v)==1400,max(abs(v$q-p.adjust(v$p,'BH')))<1e-12)};ok(TRUE,'Every saved gene-level q value replayed over 1400 tests')
 mm<-read.csv(file.path(root,'results/replicate_metrics.csv'));stopifnot(all(mm$calls==mm$TP+mm$FP),all(abs(mm$FDP-mm$FP/pmax(1,mm$calls))<1e-12),all(is.na(mm$F1)|abs(mm$F1-2*mm$TP/(mm$calls+mm$true_targets))<1e-12));ok(TRUE,'All fixed-threshold FDP and F1 identities')
 for(id in unique(d$id))for(ct in c('all',types)){dd<-d[d$id==id&d$method=='CDSeq2',];if(ct!='all')dd<-dd[dd$cell_type==ct,];m1<-mm[mm$id==id&mm$scope==ct&mm$alpha==.05&mm$workflow=='CDSeq2_with',];kk<-dd$rank<=80 & is.finite(dd$rank);cl<-dd$available & dd$q<=.05 & kk;stopifnot(m1$calls==sum(cl),m1$TP==sum(cl&dd$injected),m1$true_targets==sum(dd$injected))};ok(TRUE,'Prioritized decisions independently rebuilt from test table with full truth denominator')
}
writeLines(c(paste('Verified',nrow(completed),'completed cohorts of',nrow(m)),checks),file.path(root,'VERIFICATION.txt'))
