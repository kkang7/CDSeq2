a<-commandArgs(TRUE);root<-normalizePath(a[1]);d<-read.csv(file.path(root,'installed_package_checksums.csv'),stringsAsFactors=FALSE)
f<-vapply(seq_len(nrow(d)),function(i)file.path(find.package(d$package[i]),d$relative_path[i]),'')
stopifnot(all(file.exists(f)),all(unname(tools::md5sum(f))==d$md5))
writeLines(c('Local environment identity check passed for all recorded installed-package files.',paste(nrow(d),'DESCRIPTION, R database and native-library file checksums match the pre-run capture.'),'This binary-identity check is specific to the original local installation; independently compiled installations need not share binary hashes.'),file.path(root,'ENVIRONMENT_VERIFICATION.txt'));cat('Installed implementation files match their recorded checksums.\n')
