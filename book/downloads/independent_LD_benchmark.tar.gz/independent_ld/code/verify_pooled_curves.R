a<-commandArgs(TRUE);root<-normalizePath(a[1]);source(file.path(root,'code/curve_pooling.R'));cur<-read.csv(file.path(root,'results/precision_recall.csv'));raw<-read.csv(file.path(root,'results/test_results.csv'));settings<-unique(cur$setting);stopifnot(length(settings)==6);ncheck<-0L
for(st in settings)for(w in c('BayesPrism','CDSeq2_without','CDSeq2_with')){
 pc<-pool_curves(cur,st,w,'Excit');method<-if(w=='BayesPrism')w else'CDSeq2';d<-raw[raw$setting==st & raw$method==method & raw$cell_type=='Excit',,drop=FALSE];nt<-sum(d$injected);keep<-d$available;if(w=='CDSeq2_with')keep<-keep & is.finite(d$rank) & d$rank<=80
 stopifnot(nt==200,all(pc$true_targets==nt),all(diff(pc$calls)>=0))
 for(j in seq_len(nrow(pc))){call<-keep & d$p<=pc$threshold[j];tp<-sum(d$injected[call]);fp<-sum(call)-tp;stopifnot(pc$TP[j]==tp,pc$FP[j]==fp,pc$calls[j]==sum(call),abs(pc$recall[j]-tp/nt)<1e-12,abs(pc$precision[j]-tp/sum(call))<1e-12);ncheck<-ncheck+1L}
}
writeLines(c(paste('Independently verified',ncheck,'pooled Excit PR points against per-test evidence in all six settings.'),'Every curve uses only Excit, a common raw gene-level p threshold across cohorts, unchanged membership and all 200 injected targets per setting.'),file.path(root,'POOLED_CURVE_VERIFICATION.txt'));cat(readLines(file.path(root,'POOLED_CURVE_VERIFICATION.txt')),sep='\n')
