# Standalone simulation and native fitting; no test-truth-dependent tuning.
load_assets<-function(root){list(spec=readRDS(file.path(root,'FROZEN_SPEC.rds')),asset=readRDS(file.path(root,'inputs/frozen_parameters.rds')),LD=readRDS(file.path(root,'inputs/haplotypes.rds')))}
rsave<-function(x,f){dir.create(dirname(f),recursive=TRUE,showWarnings=FALSE);saveRDS(x,paste0(f,'.tmp'));stopifnot(file.rename(paste0(f,'.tmp'),f));writeLines(unname(tools::md5sum(f)),paste0(f,'.md5'))}
rload<-function(f){stopifnot(file.exists(f),unname(tools::md5sum(f))==readLines(paste0(f,'.md5'),warn=FALSE));readRDS(f)}
generate_genotypes<-function(LD,n){lapply(LD,function(z){ids<-sample.int(ncol(z$haplotypes),2*n,replace=TRUE);g<-z$haplotypes[,ids[seq_len(n)],drop=FALSE]+z$haplotypes[,ids[n+seq_len(n)],drop=FALSE];af<-rowMeans(g)/2;keep<-pmin(af,1-af)>=.05 & apply(g,1,sd)>0;stopifnot(any(keep));list(g=g[keep,,drop=FALSE],variants=z$variants[keep],positions=z$positions[keep],af=af[keep])})}
simulate_cohort<-function(root,row){
 f<-file.path(root,'cohorts',row$id,'simulation.rds');if(file.exists(f))return(rload(f))
 z<-load_assets(root);a<-z$asset;s<-z$spec;set.seed(row$seed);n<-row$n;G<-length(a$genes);K<-length(a$types);samples<-sprintf('%s_SYN%03d',row$id,seq_len(n));gt<-generate_genotypes(z$LD,n)
 rho0<-a$meanrho;if(row$abundance=='lowExcit'){rho0['Excit']<-.2;rho0[-match('Excit',a$types)]<-rho0[-match('Excit',a$types)]/sum(rho0[-match('Excit',a$types)])*.8}
 rho<-matrix(rgamma(n*K,shape=rep(rho0*s$rho_concentration,each=n)),n,K,dimnames=list(samples,a$types));rho<-rho/rowSums(rho)
 latent<-array(0,c(G,K,n),list(a$genes,a$types,samples));expected<-latent;truth<-latent;inj<-matrix(FALSE,s$targets,K,dimnames=list(a$targetmap$gene,a$types));causal<-matrix(NA_integer_,s$targets,K,dimnames=dimnames(inj));beta<-matrix(0,s$targets,K,dimnames=dimnames(inj))
 for(k in seq_len(K)){
  p<-a$parameters[[k]];e<-p$loading%*%matrix(rnorm(3*n),3,n)+matrix(rnorm(G*n),G,n)*p$resid_sd
  eta<-p$mean+row$heterogeneity*e
  if(row$h2>0 && a$types[k]%in%s$causal_types){
   targets<-sample.int(s$targets,s$causal_per_target_type);inj[targets,k]<-TRUE
   for(j in targets){b<-a$targetmap$block[j];v<-sample.int(nrow(gt[[b]]$g),1);g<-gt[[b]]$g[v,];causal[j,k]<-v;effect<-sample(c(-1,1),1)*p$sd[a$targetmap$gene_index[j]]*row$heterogeneity*sqrt(row$h2/(1-row$h2));beta[j,k]<-effect
    eta[a$targetmap$gene_index[j],]<-eta[a$targetmap$gene_index[j],]+effect*as.numeric(scale(g))
   }
  }
  mass<-2^eta;prop<-sweep(mass,2,colSums(mass),'/');latent[,k,]<-prop
 }
 for(i in seq_len(n)){nt<-as.numeric(rmultinom(1,s$panel_reads,rho[i,]));for(k in seq_len(K)){expected[,k,i]<-s$panel_reads*rho[i,k]*latent[,k,i];truth[,k,i]<-as.numeric(rmultinom(1,nt[k],latent[,k,i]))}}
 bulk<-apply(truth,c(1,3),sum);stopifnot(all(colSums(bulk)==s$panel_reads),all(is.finite(latent)),max(abs(apply(latent,c(2,3),sum)-1))<1e-9)
 sim<-list(row=row,genotypes=gt,bulk=bulk,truth=truth,latent=latent,rho=rho,injected=inj,causal=causal,beta=beta,seed=row$seed)
 rsave(sim,f);sim
}
cd_worker<-function(j){
 a<-get('jobasset',.GlobalEnv);sim<-get('jobsim',.GlobalEnv);s<-get('jobspec',.GlobalEnv);out<-get('jobout',.GlobalEnv)
 f<-file.path(out,sprintf('donor_%03d.rds',j));if(file.exists(f))return(rload(f))
 b<-sim$bulk[,j,drop=FALSE];seed<-sim$seed*1.0+j+100000 # below R integer max
 seed<-as.integer(seed%%2147483646)
 args<-c(s$fit,list(bulk_data=b,reference_scRNA_count=t(a$reference),reference_scRNA_annotation=a$types,cpu_number=1L,seed=seed,n_chains=1L,return_mcmc_arrays=FALSE,return_assignments=FALSE,return_posterior_sd=FALSE,drop_all_zero_genes=FALSE,verbose=FALSE))
 t0<-proc.time()[3];raw<-do.call(CDSeq2::cdseq2,args);r<-raw$cdseq_result[[1]];counts<-r$estGEP_count[a$genes,a$types,drop=FALSE];theta<-as.numeric(r$estProp[a$types,1]);err<-max(abs(rowSums(counts)-b[,1]));stopifnot(err<1e-6,abs(sum(theta)-1)<1e-8,all(is.finite(counts)),all(counts>=0));x<-list(counts=counts,theta=theta,seconds=unname(proc.time()[3]-t0),error=err);rsave(x,f);x
}
fit_cd<-function(root,row,cores=8L){
 out<-file.path(root,'cohorts',row$id);f<-file.path(out,'CDSeq2.rds');if(file.exists(f))return(invisible(rload(f)))
 z<-load_assets(root);sim<-simulate_cohort(root,row);a<-z$asset;s<-z$spec
 dir.create(file.path(out,'cd_donors'),recursive=TRUE,showWarnings=FALSE)
 cl<-parallel::makePSOCKcluster(cores,outfile=file.path(out,'cd_worker.log'));on.exit(parallel::stopCluster(cl))
 parallel::clusterCall(cl,function(paths,code,a,sim,s,out){.libPaths(paths);source(code);assign('jobasset',a,.GlobalEnv);assign('jobsim',sim,.GlobalEnv);assign('jobspec',s,.GlobalEnv);assign('jobout',out,.GlobalEnv);TRUE},.libPaths(),file.path(root,'code/benchmark.R'),a,sim,s,file.path(out,'cd_donors'))
 t0<-proc.time()[3];ans<-parallel::parLapplyLB(cl,seq_len(row$n),cd_worker)
 x<-array(unlist(lapply(ans,`[[`,'counts')),dim(sim$truth),dimnames(sim$truth));theta<-do.call(rbind,lapply(ans,`[[`,'theta'));dimnames(theta)<-list(colnames(sim$bulk),a$types)
 feat<-CDSeq2::prepare_variation_features(sim$bulk,a$mu,theta)
 # This archived scorer predates the package import schema; predictions are algebraically identical to the archived public workflow.
 pred<-rep(NA_real_,nrow(feat));outside<-rep(FALSE,nrow(feat))
 for(ct in a$types){ii<-which(feat$cell_type==ct);xx<-as.matrix(feat[ii,a$scorer$features]);for(nm in a$scorer$log_features)xx[,nm]<-log2(xx[,nm]+1e-6);m<-a$scorer$models[[ct]];ok<-rowSums(!is.finite(xx))==0;pred[ii[ok]]<-100*pmax(0,tanh(as.numeric(predict(m$fit,as.data.frame(xx[ok,,drop=FALSE]),type='response'))));outside[ii[ok]]<-rowSums(sweep(xx[ok,,drop=FALSE],2,m$lower-1e-9,'<')|sweep(xx[ok,,drop=FALSE],2,m$upper+1e-9,'>'))>0}
 scores<-data.frame(feat[c('gene','cell_type')],score=pred,outside_training_range=outside)
 rsave(list(counts=x,proportions=theta,scores=scores,seconds=unname(proc.time()[3]-t0),maximum_conservation_error=max(vapply(ans,`[[`,0,'error'))),f)
}
fit_bp<-function(root,row,cores=8L){
 f<-file.path(root,'cohorts',row$id,'BayesPrism.rds');if(file.exists(f))return(invisible(rload(f)))
 z<-load_assets(root);sim<-simulate_cohort(root,row);a<-z$asset;s<-z$spec;stopifnot(as.character(packageVersion('BayesPrism'))==s$packages[['BayesPrism']])
 ref<-BayesPrism::cleanup.genes(a$reference,input.type='GEP',species='hs',gene.group=s$bp$cleanup,exp.cells=s$bp$exp.cells)
 p<-BayesPrism::new.prism(reference=ref,input.type='GEP',cell.type.labels=a$types,cell.state.labels=a$types,key=NULL,mixture=t(sim$bulk),outlier.cut=s$bp$outlier.cut,outlier.fraction=s$bp$outlier.fraction,pseudo.min=1e-8)
 genes<-colnames(p@mixture);t0<-proc.time()[3];Sys.setenv(R_LIBS=paste(.libPaths(),collapse=.Platform$path.sep))
 fit<-BayesPrism::run.prism(p,n.cores=cores,update.gibbs=TRUE,gibbs.control=c(s$bp[c('chain.length','burn.in','thinning','alpha')],list(seed=as.integer((row$seed+200000)%%2147483646))))
 dir.create(tempdir(),recursive=TRUE,showWarnings=FALSE)
 x<-array(0,c(length(genes),length(a$types),row$n),list(genes,a$types,colnames(sim$bulk)))
 for(ct in a$types)x[,ct,]<-t(BayesPrism::get.exp(fit,state.or.type='type',cell.name=ct)[colnames(sim$bulk),genes,drop=FALSE])
 theta<-BayesPrism::get.fraction(fit,which.theta='final',state.or.type='type')[colnames(sim$bulk),a$types,drop=FALSE]
 err<-max(abs(apply(x,c(1,3),sum)-sim$bulk[genes,,drop=FALSE]));stopifnot(err<1e-6,all(is.finite(x)),all(x>=0))
 qc<-data.frame(gene=a$genes,cleanup_retained=a$genes%in%colnames(ref),retained=a$genes%in%genes,target=a$genes%in%a$targetmap$gene)
 rsave(list(counts=x,proportions=theta,preprocessing=qc,seconds=unname(proc.time()[3]-t0),maximum_conservation_error=err),f)
}
