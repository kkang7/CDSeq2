# Preserve binary64 values through CSV: default write.csv's 15-digit formatting
# can collapse distinct association p values and make exported PR steps ambiguous.
# This affects serialization only, never fitted estimates, rankings or decisions.
write_csv_exact <- function(d, path) {
  serialized <- d
  for (nm in names(serialized)) {
    if (is.double(serialized[[nm]])) {
      x <- serialized[[nm]]
      serialized[[nm]] <- ifelse(is.na(x), NA_character_, sprintf('%.17g', x))
    }
  }
  write.csv(serialized, path, row.names=FALSE, na='')
  invisible(d)
}
