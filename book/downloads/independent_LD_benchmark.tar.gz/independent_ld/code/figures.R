source(file.path(commandArgs(TRUE)[1],'code/cell_type_labels.R'))
a<-commandArgs(TRUE);root<-normalizePath(a[1]);o<-if(length(a)>1)a[2]else file.path(root,'figures');dir.create(o,recursive=TRUE,showWarnings=FALSE);td<-file.path(root,'results')
fixed<-read.csv(file.path(td,'replicate_metrics.csv'));cur<-read.csv(file.path(td,'precision_recall.csv'));nul<-read.csv(file.path(td,'global_null_repeats.csv'));expr<-read.csv(file.path(td,'expression_recovery.csv'));sm<-read.csv(file.path(td,'summary_metrics.csv'))
wf<-c('BayesPrism','CDSeq2_without','CDSeq2_with');labs<-c('BayesPrism','CDSeq2 (without gene-type prioritization)','CDSeq2 (with gene-type prioritization; top 40%)');cols<-c('#D55E00','#777777','#0072B2');ltys<-c(3,2,1);pch<-c(17,15,16)
base<-c('N60_H10','N60_H30','N120_H10','N120_H30');allset<-c(base,'N120_H30_lowExcit','N120_H30_highHeterogeneity');titles<-c('n = 60 | h2 = 0.10','n = 60 | h2 = 0.30','n = 120 | h2 = 0.10','n = 120 | h2 = 0.30','n = 120 | lower excitatory-neuron\nRNA abundance','n = 120 | high heterogeneity');names(titles)<-allset
fig<-function(name,w,h,fun){for(ext in c('pdf','png')){f<-file.path(o,paste0(name,'.',ext));if(ext=='pdf')pdf(f,width=w,height=h,useDingbats=FALSE)else png(f,width=w,height=h,units='in',res=300,type='cairo');fun();dev.off()}}
label<-function(x)mtext(x,3,line=1.1,adj=-.08,font=2,cex=1.2)
leg<-function(note=NULL){par(oma=c(0,0,0,0),fig=c(0,1,0,.095),new=TRUE,mar=c(0,0,0,0));plot.new();legend('center',legend=labs,col=cols,pch=pch,lty=ltys,lwd=2,bty='n',cex=.78);if(!is.null(note))text(.5,.09,note,cex=.62)}
pointplot<-function(metric,settings=base,main='',ylabel='',xt=NULL,ylim=c(0,1)){
 plot(NA,xlim=c(.55,length(settings)+.45),ylim=ylim,xaxt='n',xlab='',ylab=ylabel,main=main,cex.main=.94);abline(h=pretty(ylim),col='#EEEEEE');if(metric=='FDP')abline(h=.05,lty=2,col='#BB5555')
 axis(1,seq_along(settings),labels=if(is.null(xt))c('60\n0.10','60\n0.30','120\n0.10','120\n0.30')else xt,tick=FALSE,cex.axis=.78)
 for(j in seq_along(wf)){z<-subset(sm,workflow==wf[j]&scope=='Excit'&alpha==.05);z<-z[match(settings,z$setting),];v<-z[[paste0('mean_',metric)]];se<-z[[paste0('se_',metric)]];xx<-seq_along(settings)+(j-2)*.13;good<-is.finite(v)&is.finite(se)&se>0;if(any(good))arrows(xx[good],pmax(0,v[good]-se[good]),xx[good],pmin(1,v[good]+se[good]),angle=90,code=3,length=.035,col=cols[j]);points(xx,v,pch=pch[j],col=cols[j],cex=1.1)}
}
source(file.path(root,'code/curve_pooling.R'))
pooledcurve<-function(st,w,scope='Excit')pool_curves(cur,st,w,scope)
prplot<-function(st,main=NULL){plot(NA,xlim=c(0,1),ylim=c(0,1.03),xaxs='i',yaxs='i',xlab='Full-target recall',ylab='Precision',main='',cex.main=.94);title(main=if(is.null(main))titles[st]else main,line=2.0,cex.main=.94);abline(h=seq(0,1,.2),v=seq(0,1,.2),col='#EEEEEE')
 for(j in seq_along(wf)){p<-pooledcurve(st,wf[j]);p<-p[p$calls>0,];lines(p$recall,p$precision,type='s',col=cols[j],lty=ltys[j],lwd=1.8);v<-subset(fixed,setting==st&workflow==wf[j]&scope=='Excit'&alpha==.05);if(sum(v$calls)>0)points(sum(v$TP)/sum(v$true_targets),sum(v$TP)/sum(v$calls),pch=21,bg=cols[j],col='white',cex=1.25)}
 mtext('Circles: predefined q <= 0.05',3,line=.05,cex=.7,col='#555555')
}
nullplot<-function(){plot(NA,xlim=c(.6,3.4),ylim=c(0,1),xaxt='n',xlab='Nominal full-family BH threshold',ylab='Global-null rejection probability',main='Global null | ten expression cohorts',cex.main=.94);axis(1,1:3,c('0.01','0.05','0.10'));abline(h=seq(0,1,.2),col='#EEEEEE');lines(1:3,c(.01,.05,.1),col='#333333',lty=2)
 for(j in seq_along(wf))for(i in 1:3){aa<-c(.01,.05,.1)[i];v<-subset(nul,workflow==wf[j]&scope=='all'&alpha==aa);p<-tapply(v$FDP,v$id,mean);se<-sd(p)/sqrt(length(p));xx<-i+(j-2)*.15;points(rep(xx,length(p)),p,col=adjustcolor(cols[j],.2),pch=16,cex=.5);if(is.finite(se)&&se>0)arrows(xx,max(0,mean(p)-se),xx,min(1,mean(p)+se),angle=90,code=3,length=.035,col=cols[j]);points(xx,mean(p),col=cols[j],pch=pch[j],cex=1.1)}
}
fig('Figure_6_independent_LD_benchmark',11.5,10.4,function(){par(mfrow=c(3,2),mar=c(4.3,4.5,3.8,1),oma=c(5.6,0,0,0),mgp=c(2.8,.85,0),las=1,cex=.95)
 pointplot('FDP',main='Excitatory neurons: mean FDP at q <= 0.05',ylabel='Mean replicate FDP');mtext('Sample size / nominal genetic fraction',1,2.9,cex=.73);label('A')
 pointplot('full_recall',main='Excitatory neurons: injected-target recovery',ylabel='Full-target recall');mtext('Sample size / nominal genetic fraction',1,2.9,cex=.73);label('B')
 pointplot('F1',main='Excitatory neurons: F1 at q <= 0.05',ylabel='F1 score');mtext('Sample size / nominal genetic fraction',1,2.9,cex=.73);label('C')
 prplot('N120_H30',main='Excitatory neurons: precision-recall\nn = 120, h2 = 0.30');label('D')
 pointplot('FDP',settings=c('N120_H30','N120_H30_lowExcit','N120_H30_highHeterogeneity'),xt=c('Typical','Lower excitatory\nneuron abundance','Higher\nheterogeneity'),main='Excitatory neurons: attribution under stress',ylabel='Mean replicate FDP');label('E')
 nullplot();label('F');leg('Error bars: Monte Carlo SE across independent expression cohorts; fixed retention = 40%.')
})
fig('Figure_S12_LD_precision_recall',11.5,8.7,function(){par(mfrow=c(2,3),mar=c(4.2,4.2,3.8,.7),oma=c(5.6,0,0,0),mgp=c(2.7,.8,0),las=1,cex=.9);for(i in seq_along(allset)){prplot(allset[i]);label(LETTERS[i])};leg('Five independent signal cohorts per setting; curves pool counts at a common gene-level p threshold.')})
fig('Figure_S13_LD_all_cell_types',13.6,8.8,function(){par(mfrow=c(2,3),mar=c(6.0,7.2,4,.6),oma=c(0,0,2,0),mgp=c(2.6,.8,0),las=1,cex=.9);types<-c('Astro','Excit','Inhib','Oligo','OPC','Immune','Vascular');pnum<-0
 for(metric in c('FDP','full_recall'))for(j in 1:3){pnum<-pnum+1;mat<-matrix(NA_real_,7,6);for(k in 1:7)for(i in 1:6){v<-subset(sm,workflow==wf[j]&scope==types[k]&setting==allset[i]&alpha==.05);if(nrow(v))mat[k,i]<-v[[paste0('mean_',metric)]]}
 palette<-if(metric=='FDP')colorRampPalette(c('#FAFAFA','#F5C5AE','#A41E28'))(101)else colorRampPalette(c('#FAFAFA','#9DC7E0','#075C95'))(101)
 plot(NA,xlim=c(.5,6.5),ylim=c(.5,7.5),xaxt='n',yaxt='n',xlab='',ylab='',main='',xaxs='i',yaxs='i');mtext(if(j==1)'BayesPrism'else'CDSeq2',3,line=2,font=2,cex=.9);if(j>1)mtext(if(j==2)'(without gene-type prioritization)'else'(with gene-type prioritization)',3,line=1,font=2,cex=.74)
 for(k in 1:7)for(i in 1:6){v<-mat[k,i];rect(i-.5,8-k-.5,i+.5,8-k+.5,col=if(is.na(v))'#DDDDDD'else palette[1+round(100*v)],border='white');text(i,8-k,if(is.na(v))'NA'else sprintf('%.2f',v),cex=.72,col=if(is.finite(v)&&v>.65)'white'else'#333333')}
 axis(2,7:1,ct_name(types,TRUE),tick=FALSE,cex.axis=.63);axis(1,1:6,c('60 / .10','60 / .30','120 / .10','120 / .30','Lower excitatory-neuron\nabundance','High hetero.'),las=2,tick=FALSE,cex.axis=.73);mtext(if(metric=='FDP')'Mean replicate FDP'else'Full-target recall',3,line=.05,cex=.72);label(LETTERS[pnum])
 };mtext('Five replicates per setting | q <= 0.05 | gray = no injected target denominator',outer=TRUE,side=3,line=.5,cex=.85)
})
fig('Figure_S14_LD_expression_recovery',11.5,8.9,function(){par(mfrow=c(2,3),mar=c(4.3,4.3,3.2,.8),oma=c(5.6,0,0,0),mgp=c(2.8,.8,0),las=1,cex=.9)
 for(i in seq_along(allset)){st<-allset[i];plot(NA,xlim=c(.5,3.5),ylim=c(-1,1),xaxt='n',xlab='',ylab='Excitatory-neuron expression recovery (r)',main=titles[st],cex.main=.94);abline(h=seq(-1,1,.5),col='#EEEEEE')
  for(j in 1:3){v<-subset(expr,setting==st&cell_type=='Excit'&method==if(j==1)'BayesPrism'else'CDSeq2');if(j==3)v<-v[v$selected,];rr<-v$r_CPM[is.finite(v$r_CPM)];if(length(rr)>1){de<-density(rr,from=max(-1,min(rr)),to=min(1,max(rr)));xx<-de$y/max(de$y)*.34;polygon(c(j-xx,rev(j+xx)),c(de$x,rev(de$x)),col=adjustcolor(cols[j],.68),border=cols[j]);q<-quantile(rr,c(.25,.5,.75));segments(j,q[1],j,q[3],lwd=3,col='#333333');points(j,q[2],pch=21,bg='white',cex=.8)};mtext(paste0('n=',length(rr)),1,at=j,line=.5,cex=.72)}
  axis(1,1:3,c('BayesPrism','Without\nprioritization','With\nprioritization'),tick=FALSE,line=1.5,cex.axis=.7);label(LETTERS[i])
 };leg('Within each cohort/type, selection retains 80 of 200 target profiles; undefined correlations are omitted only from plotting.')
})
fig('Figure_S15_LD_retention_sensitivity',11.5,8.7,function(){par(mfrow=c(2,3),mar=c(4.2,4.3,3.2,.7),oma=c(5.6,0,0,0),mgp=c(2.7,.8,0),las=1,cex=.9)
 for(i in seq_along(allset)){st<-allset[i];plot(NA,xlim=c(0,1),ylim=c(0,1),xaxs='i',yaxs='i',xlab='Full-target recall',ylab='Mean replicate FDP',main=titles[st],cex.main=.94);abline(h=seq(0,1,.2),v=seq(0,1,.2),col='#EEEEEE');abline(h=.05,lty=2,col='#BB5555')
  zz<-subset(sm,setting==st&scope=='Excit'&alpha==.05&grepl('^CDSeq2',workflow));zz<-zz[order(zz$retention),];lines(zz$mean_full_recall,zz$mean_FDP,col='#777777',lwd=1.5);points(zz$mean_full_recall,zz$mean_FDP,col='#777777',pch=1)
  for(j in 1:3){v<-subset(sm,setting==st&scope=='Excit'&alpha==.05&workflow==wf[j]);points(v$mean_full_recall,v$mean_FDP,col=cols[j],pch=pch[j],cex=1.3)};label(LETTERS[i])
 };leg('Open points along the CDSeq2 line: fixed retentions 20%, 40%, 60%, 80%, 100%; blue highlights the predefined 40%.')
})
