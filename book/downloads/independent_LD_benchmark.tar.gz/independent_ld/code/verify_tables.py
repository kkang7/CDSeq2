"""Independent, standard-library verification of all exported decisions/curves."""
import collections,csv,math,pathlib,sys
root=pathlib.Path(sys.argv[1]);p=root/'results'
def read(name): return list(csv.DictReader((p/name).open()))
def val(x):return float(x) if x else float('nan')
def boolean(x):return x in ('TRUE','True','1')
def close(a,b):return (math.isnan(a) and math.isnan(b)) or math.isclose(a,b,abs_tol=1e-11,rel_tol=1e-10)
tests=read('test_results.csv');groups=collections.defaultdict(list)
for r in tests:groups[r['id'],r['method']].append(r)
assert len(groups)==90
for key,rows in groups.items():
    assert len(rows)==1400 and len({(r['gene'],r['cell_type']) for r in rows})==1400
    sortedrows=sorted(rows,key=lambda r:val(r['p'])); running=1.
    for i in reversed(range(len(rows))):
        r=sortedrows[i];running=min(running,val(r['p'])*len(rows)/(i+1));assert close(running,val(r['q']))
metrics=read('replicate_metrics.csv');count=0
for r in metrics:
    if r['setting']=='GLOBAL_NULL':continue
    w=r['workflow']; method='CDSeq2' if w.startswith('CDSeq2') else w;rows=groups[r['id'],method]
    if r['scope']!='all':rows=[x for x in rows if x['cell_type']==r['scope']]
    ret=val(r['retention']); chosen=[x for x in rows if ret==1 or (math.isfinite(val(x['rank'])) and val(x['rank'])<=math.floor(ret*200))]
    calls=[x for x in chosen if boolean(x['available']) and val(x['q'])<=val(r['alpha'])]
    tp=sum(boolean(x['injected']) for x in calls);fp=len(calls)-tp;nt=sum(boolean(x['injected']) for x in rows)
    for field,n in [('targets',len(rows)),('selected',len(chosen)),('calls',len(calls)),('TP',tp),('FP',fp),('true_targets',nt)]:assert int(r[field])==n,(r,field,n)
    assert close(val(r['FDP']),fp/max(1,len(calls)))
    assert close(val(r['F1']),2*tp/(len(calls)+nt) if nt else float('nan'))
    count+=1
curves=read('precision_recall.csv');cg=collections.defaultdict(list)
for r in curves:cg[r['id'],r['workflow'],r['scope']].append(r)
for key,rows in cg.items():
    ident,w,ct=key;method='CDSeq2' if w.startswith('CDSeq2')else w;raw=groups[ident,method]
    raw=[r for r in raw if (ct=='all' or r['cell_type']==ct) and boolean(r['available']) and (w!='CDSeq2_with' or val(r['rank'])<=80)]
    raw.sort(key=lambda r:val(r['p']));i=tp=0
    for r in sorted(rows,key=lambda r:val(r['threshold'])):
        while i<len(raw) and val(raw[i]['p'])<=val(r['threshold']):tp+=boolean(raw[i]['injected']);i+=1
        assert int(r['TP'])==tp and int(r['FP'])==i-tp and int(r['calls'])==i, (key,r['threshold'],'saved',(r['TP'],r['FP'],r['calls']),'recomputed',(tp,i-tp,i),'nearby',[(x['gene'],x['p'],x['injected']) for x in raw[max(0,i-3):i+2]])
        assert close(val(r['precision']),tp/i)
        assert close(val(r['F1']),2*tp/(i+int(r['true_targets'])))
caps=read('retrospective_matched_FDP.csv')
for r in caps:
    rows=cg[r['id'],r['workflow'],r['scope']];ok=[x for x in rows if val(x['FDP'])<=val(r['cap'])];best=max([int(x['TP']) for x in ok]+[0]);assert int(r['TP'])==best
summary=read('summary_metrics.csv');mg=collections.defaultdict(list)
keys=['setting','n','h2','workflow','retention','scope','alpha']
for r in metrics:mg[tuple(r[k] for k in keys)].append(r)
for r in summary:
    rows=mg[tuple(r[k] for k in keys)];assert int(r['replicates'])==len(rows)
    assert close(val(r['mean_FDP']),sum(val(x['FDP']) for x in rows)/len(rows))
null=read('global_null_repeats.csv');assert len(null)==24000 and len({x['id'] for x in null})==10
for r in null:assert int(r['TP'])==0 and int(r['true_targets'])==0 and val(r['FDP'])==int(int(r['calls'])>0)
report=f'Independent Python verification passed: {len(tests)} gene/type rows; {count} fixed-threshold summaries; {len(curves)} PR points; {len(caps)} truth-matched optima; {len(summary)} replicate summaries; {len(null)} null summaries. BH, selection counts, full-target denominators, F1, mean FDP and all decisions independently reconstructed.\n'
(root/'TABLE_VERIFICATION.txt').write_text(report);print(report)
