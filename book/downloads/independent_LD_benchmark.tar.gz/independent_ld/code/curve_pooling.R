# Pool per-cohort PR counts at one common gene-level p threshold.
# Use explicit data-frame indexing to avoid argument/column-name shadowing.
pool_curves<-function(cur,setting,workflow,scope='Excit'){
 z<-cur[cur$setting==setting & cur$workflow==workflow & cur$scope==scope,,drop=FALSE]
 if(!nrow(z))return(data.frame(threshold=numeric(),TP=numeric(),FP=numeric(),true_targets=numeric(),precision=numeric(),recall=numeric(),calls=numeric()))
 ids<-unique(z$id);thresholds<-sort(unique(z$threshold));tp<-fp<-numeric(length(thresholds));nt<-0
 for(id in ids){v<-z[z$id==id,,drop=FALSE];v<-v[order(v$threshold),,drop=FALSE];stopifnot(!anyDuplicated(v$threshold),length(unique(v$true_targets))==1);j<-findInterval(thresholds,v$threshold);tp<-tp+c(0,v$TP)[j+1];fp<-fp+c(0,v$FP)[j+1];nt<-nt+v$true_targets[1]}
 data.frame(threshold=thresholds,TP=tp,FP=fp,true_targets=nt,precision=ifelse(tp+fp>0,tp/(tp+fp),NA_real_),recall=tp/nt,calls=tp+fp)
}
