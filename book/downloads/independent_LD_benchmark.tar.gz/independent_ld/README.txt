CDSeq2 independent LD benchmark, reconstructed-input version

All 40 cohorts and 3600 synthetic individuals were fitted anew using the frozen
training-derived parameters and scorer in this folder. Native cohort caches are
not distributed; complete per-test results and verification records are included.
The source archive was independently installed and exactly reproduced one new
native donor fit. SIMULATION_REPLAY.txt records an exact new-cohort generator replay.

From the manuscript bundle directory, to rerun inference into this folder:
  python3 CDSeq2_independent_LD_benchmark_v2/code/run_all.py CDSeq2_independent_LD_benchmark_v2 8
  Rscript CDSeq2_independent_LD_benchmark_v2/code/analyze.R CDSeq2_independent_LD_benchmark_v2
  Rscript CDSeq2_independent_LD_benchmark_v2/code/export_design.R CDSeq2_independent_LD_benchmark_v2
  Rscript CDSeq2_independent_LD_benchmark_v2/code/summarize_null.R CDSeq2_independent_LD_benchmark_v2
  Rscript CDSeq2_independent_LD_benchmark_v2/code/verify.R CDSeq2_independent_LD_benchmark_v2
  python3 CDSeq2_independent_LD_benchmark_v2/code/verify_tables.py CDSeq2_independent_LD_benchmark_v2
  Rscript CDSeq2_independent_LD_benchmark_v2/code/verify_pooled_curves.R CDSeq2_independent_LD_benchmark_v2

To regenerate the figures from included results without inference:
  Rscript CDSeq2_independent_LD_benchmark_v2/code/figures.R CDSeq2_independent_LD_benchmark_v2 figures

See DEPENDENCIES.txt and the captured dependency tables. The frozen runtime guard
requires recorded package versions. Input/code hashes prevent mixing incompatible
caches. Use an empty cohorts directory for a new execution; no historical cohort
checkpoints or evaluation profiles are needed. Five replicates per signal setting,
fixed primary retention 40%, fixed q=0.05, and all declared sensitivities are retained.
No threshold or membership was tuned to this rerun's truth.
