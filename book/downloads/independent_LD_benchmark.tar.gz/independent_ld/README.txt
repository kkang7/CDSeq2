CDSeq2 independent synthetic-cohort, local-LD benchmark (revision 13)

This benchmark performs NEW native inference with BayesPrism and CDSeq2.
CDSeq2 with prioritization reuses the same CDSeq2 expression and q values,
retaining the frozen GAM6 top 40% of gene/type profiles within each type.
All 40 native cohorts and downstream analyses are complete. Verification
records and results/RESULTS_REPORT.txt summarize the executed checks and outcomes.

Design
- 30 signal cohorts: six settings, five independently generated cohorts each.
- 10 independent null-expression cohorts, with 100 new genotype realizations each.
- 3600 new synthetic individuals overall; n = 60 or 120.
- 2000 modeled genes, seven cell types, 200000 modeled-panel reads per sample.
- 200 target genes sampled using training expression eligibility, not score strata.
- 40 injected genes in each of Excit, Inhib and Oligo; direct-effect truth.
- 40 local LD windows drawn from 503 public 1000 Genomes European individuals.
- All test-cohort common SNPs within each assigned window are tested.
- Frozen primary rule: within-gene Bonferroni minimum p, global BH over 1400
  gene/type tests, q <= 0.05, then top-40% selection for CDSeq2 only.
- Independent means independent synthetic draws conditional on fixed training-
  derived parameters and a haplotype reference, not new biological donors.
- Windows are assigned to genes for simulation; they are not real gene cis maps.
- No scorer tuning, no truth-selected primary thresholds and no donor exclusion.

Files
FROZEN_SPEC.rds/.txt and DESIGN_FREEZE.txt: pre-outcome specification.
cohorts.csv: fixed cohorts and seeds.
inputs/frozen_parameters.rds: compact training-derived parameters, reference
  aggregate, target map and trained scorer. Original individual training or
  validation expression matrices are not required to rerun the benchmark.
inputs/haplotypes.rds: filtered public reference blocks.
installed_package_checksums.csv: exact installed implementation identities.
dependency_versions.csv and dependency_sessionInfo.txt: dependency versions and
  an environment capture loading the primary packages.
code/: generator, native inference, analysis, independent verification, figures.
cohorts/: generated simulations and native fit caches (large, local run only).
results/: computed test-level and summary tables.
TABLE_SCHEMA.txt: variable definitions, units, workflows and denominator rules.

Run after installing CDSeq2 and the recorded R dependencies
From this directory's parent, using a terminal:
  python3 CDSeq2_independent_LD_benchmark_v1/code/run_all.py CDSeq2_independent_LD_benchmark_v1 8
  Rscript --vanilla CDSeq2_independent_LD_benchmark_v1/code/analyze.R CDSeq2_independent_LD_benchmark_v1
  Rscript --vanilla CDSeq2_independent_LD_benchmark_v1/code/export_design.R CDSeq2_independent_LD_benchmark_v1
  Rscript --vanilla CDSeq2_independent_LD_benchmark_v1/code/summarize_null.R CDSeq2_independent_LD_benchmark_v1
  Rscript --vanilla CDSeq2_independent_LD_benchmark_v1/code/verify.R CDSeq2_independent_LD_benchmark_v1
  python3 CDSeq2_independent_LD_benchmark_v1/code/verify_tables.py CDSeq2_independent_LD_benchmark_v1
  Rscript --vanilla CDSeq2_independent_LD_benchmark_v1/code/verify_pooled_curves.R CDSeq2_independent_LD_benchmark_v1
  Rscript --vanilla CDSeq2_independent_LD_benchmark_v1/code/figures.R CDSeq2_independent_LD_benchmark_v1

The launcher uses Rscript from PATH (or the RSCRIPT environment variable).
The last launcher argument is the number of workers. Eight was used here.
It fits one cohort at a time, parallelizing within each method. Fits have
checksummed caches. Completed fits are reused; an interrupted incomplete
cohort can reuse individual CDSeq2 donor fits. FIT_LOCK prevents duplicate
concurrent fits; remove a stale lock only after confirming its owning run
has stopped. Do not mix changed methods, inputs or design with old caches.
Two controllers can traverse opposite orders using --reverse; this changes
scheduling only and was used to utilize the local 16-core machine.

The complete run takes substantial time; use saved results to regenerate
figures without rerunning inference. No model fitting occurs during LaTeX
compilation. Keep the frozen input assets with this script folder.

Rebuilding input assets
prepare.R is for rebuilding from the original project input directory, not
needed for ordinary reproduction from included compact assets. It refuses
to overwrite an existing frozen specification. fetch_haplotypes.R rebuilds
the public panel subset if its population panel and VCF tabix index have
first been downloaded from the documented 1000 Genomes release URLs.

Interpretation
Mean replicate FDP (including zero for no calls) estimates expected direct-
target attribution error under signal settings. This is not automatically the
FDR for testing zero marginal association; CPM normalization can create indirect
associations. Pooled precision is a different summary. Five signal
replicates per setting imply substantial Monte Carlo uncertainty. Null
uncertainty is clustered over ten expression cohorts; 100 genotype repeats
within one cohort are not 100 independent expression datasets. Good global-
null behavior does not establish cell-type attribution control when another
type carries a real effect. Scorer out-of-training-range flags are reported.
True discovery means a gene/type with a directly injected effect, not correct
localization of the causal SNP. CPM normalization can induce indirect effects.
Retrospective matched-FDP tables remain diagnostic, not deployment thresholds.

Exact CDSeq2 source snapshot
source_snapshot/CDSeq2_0.0.0.9000.tar.gz was built from the shared package source
without modifying that source. All 136 R function bodies/formals match the
implementation used for fitting. An isolated installation of the source archive
reproduced the first benchmark donor's allocated counts and RNA fractions with
maximum absolute differences of zero (SOURCE_BUILD_REPLAY.txt). This is a
one-donor source-build identity check, not a second run of all 40 cohorts.
The archive requires R >= 4.1.0 and a suitable compiler plus its listed imports;
the experiment was run with R 4.6.1. The build library used for validation was
separate and did not replace the user's installed CDSeq2 package.

Primary statistical caveat
The OLS association model is retained exactly as frozen even if its nominal
thresholds prove miscalibrated. Null inflation can arise with the observed
components as well as inferred profiles. The package's prioritization feature
must not be described as an FDR-control procedure. Undefined precision for no
calls is not reported as perfect precision. Lower FDP without true discoveries
is not evidence of useful discovery recovery.

The unchanged archived scorer-reference workflow is included under
source_snapshot/archived_scoring_workflow.R so verify.R can independently replay
new-cohort feature transformations and predictions without the original project
directory. It is a verification reference, not another inference pipeline.

inputs/LD_reference_QC.csv retains the original candidate-window numbers.
Use results/LD_reference_windows.csv (Table S27), whose block field is 1-40,
when joining window metadata to the target-gene map or injection/test tables.
